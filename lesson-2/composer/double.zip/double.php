<?php
/**
 * Created by PhpStorm.
 * User: neo
 * Date: 21.10.14
 * Time: 15:05
 */

    echo "work";